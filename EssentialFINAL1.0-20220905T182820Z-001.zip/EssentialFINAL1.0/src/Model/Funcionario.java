/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.sql.Date;
/**
 *
 * @author leticia_2
 */
public class Funcionario {
    
   private int funcionarioId; 
   private  String nome; 
   private  String cpf;
   private  String rg; 
   private  java.sql.Date dataNascimento; 
   private  String email; 
   private  String telefone;
   private  String endereco;;
   private  String cep; 
   private  String usuario; 
    private String senha; 
    private String funcao;
     private  String bairro; 
     
     
     public Funcionario(){
         
     }

     

   
     /*   public Funcionario(Integer funcionarioId, String nome,String cpf,String rg, Date dataNascimento,String email,String telefone,
     String bairro,String cep, String usuario,String senha,String funcao) {
     this.funcionarioId = funcionarioId;
     this.nome = nome;
     this.cpf = cpf;
     this.rg = rg;
     this.dataNascimento = dataNascimento;
     this.email = email;
     this.telefone = telefone;
     this.endereco = endereco;
     this.bairro = bairro;
     this.cep = cep;
     this.usuario = usuario;
     this.senha = senha;
     this.funcao = funcao;*/

    public Funcionario(Integer funcionarioId, String nome,String cpf,String rg, Date dataNascimento,String email,String telefone,
     String bairro,String cep, String usuario,String senha,String funcao) {
     this.funcionarioId = funcionarioId;
     this.nome = nome;
     this.cpf = cpf;
     this.rg = rg;
     this.dataNascimento = dataNascimento;
     this.email = email;
     this.telefone = telefone;
     this.endereco = endereco;
     this.bairro = bairro;
     this.cep = cep;
     this.usuario = usuario;
     this.senha = senha;
     this.funcao = funcao;
        
    }

    public Funcionario(int aInt) {
       
    }

    
   

    public int getFuncionarioID() {
        return funcionarioId;
    }

    public void setFuncionarioID(int funcionarioID) {
        this.funcionarioId = funcionarioId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }
     
     
         

    
    
     

   
}
