/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.sql.Date;
/**
 *
 * @author leticia_2    private Integer clienteId;
    private String nome;
    private String cpf;
    private String rg;    
    private Date dataNascimento;
    private String sexo;
    private String email;
    private String telefone;
    private String endereco;
    private String bairro;
    private String cidade;
    private String cep;        
    private String cnh; 
 */
public class Locacao {
    
    
   private Integer idLocacao;
   private String nomeCliente;
   private String cnh;
   private Date dataLocacao;
   private Date dataEntrega;
   private String marca;
   private String servicos;
   private Integer funcionarioID;
   private Integer clienteID;
   private Integer veiculoID;
   private Date dataDevolucao;
   private String placa;

    public Locacao() {
       
    }

    public Locacao(Integer idLocacao, String nomeCliente, String cnh,  Date dataLocacao,Date dataEntrega,  String marca, String servicos, 
      Integer funcionarioID, Integer clienteID, Integer veiculoID, Date dataDevolucao) {
        this.idLocacao = idLocacao;
        this.nomeCliente = nomeCliente;
        this.cnh = cnh;
        this.dataLocacao = dataLocacao;
        this.dataEntrega = dataEntrega;
        this.marca = marca;
        this.servicos = servicos;
        this.funcionarioID = funcionarioID;
        this.veiculoID = veiculoID;
        this.dataDevolucao = dataDevolucao;
        this.placa = placa; 
        
    }

    public Locacao(Integer idLocacao, String nomeCliente, String cnh,  Date dataLocacao,Date dataEntrega,  String marca, String servicos, 
      Integer funcionarioID, Integer clienteID, Integer veiculoID, Date dataDevolucao) {
        this.idLocacao = idLocacao;
        this.nomeCliente = nomeCliente;
        this.cnh = cnh;
        this.dataLocacao = dataLocacao;
        this.dataEntrega = dataEntrega;
        this.marca = marca;
        this.servicos = servicos;
        this.funcionarioID = funcionarioID;
        this.veiculoID = veiculoID;
        this.dataDevolucao = dataDevolucao;
        this.placa = placa;
        
    }

    public Locacao(int aInt, String string, Date date, Date date0, Date date1, String string0, String string1) {
            }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

   

       

   

    //public Locacao(int aInt, String string, String string0, String string1, Date date, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9) {
        
   // }
    public Integer getIdLocacao() {
        return idLocacao;
    }

    public void setIdLocacao(Integer idLocacao) {
        this.idLocacao = idLocacao;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String NomeCliente) {
        this.nomeCliente = NomeCliente;
    }

    public String getCnh() {
        return cnh;
    }

    public void setCnh(String cnh) {
        this.cnh = cnh;
    }

    public Date getDataLocacao() {
        return dataLocacao;
    }

    public void setDataLocacao(Date dataLocacao) {
        this.dataLocacao = dataLocacao;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(Date dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getServicos() {
        return servicos;
    }

    public void setServicos(String servicos) {
        this.servicos = servicos;
    }

    public Integer getFuncionarioID() {
        return funcionarioID;
    }

    public void setFuncionarioID(Integer funcionarioID) {
        this.funcionarioID = funcionarioID;
    }

    public Integer getClienteID() {
        return clienteID;
    }

    public void setClienteID(Integer clienteID) {
        this.clienteID = clienteID;
    }

    public Integer getVeiculoID() {
        return veiculoID;
    }

    public void setVeiculoID(Integer veiculoID) {
        this.veiculoID = veiculoID;
    }

    public Date getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(Date dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }
}
   