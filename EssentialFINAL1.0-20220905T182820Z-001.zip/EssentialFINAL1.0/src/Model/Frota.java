/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


/**
 *
 * @author leticia_2
 */
public class Frota {
   
   private int VeiculoID;
   private String Placa;
   private  String Modelo; 
   private int Ano;
   private String Cor; 
   private String Categoria; 
   private String Motor; 
   private int FornecedorID; 

    public int getVeiculoID() {
        return VeiculoID;
    }

    public void setVeiculoID(int VeiculoID) {
        this.VeiculoID = VeiculoID;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public int getAno() {
        return Ano;
    }

    public void setAno(int Ano) {
        this.Ano = Ano;
    }

    public String getCor() {
        return Cor;
    }

    public void setCor(String Cor) {
        this.Cor = Cor;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String Categoria) {
        this.Categoria = Categoria;
    }

    public String getMotor() {
        return Motor;
    }

    public void setMotor(String Motor) {
        this.Motor = Motor;
    }

    public int getFornecedorID() {
        return FornecedorID;
    }

    public void setFornecedorID() {
        this.FornecedorID = FornecedorID;
    }
}
