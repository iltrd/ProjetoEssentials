/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

    
    
import Model.Fornecedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author leticia_2
 */
public class FornecedorDao {
    
     private Connection conexao;
    private PreparedStatement stmt;
    private Statement st;
     public ArrayList<Fornecedor> lista;
     
    public FornecedorDao(ArrayList<Fornecedor>l){
        lista = new ArrayList<Fornecedor>(l);
    }
     public FornecedorDao(){
           conexao = new ConnectionFactory().getConexao();
    }
             public void Cadastrar(Fornecedor fornecedor){
             String sql = "INSERT INTO cliente(NomeFantasia, RazaoSocial, CNPJ, Endereco, Bairro, Cidade, CEP, Email, Telefone) VALUES (?,?,?,?,?,?,?,?,?)";
                    try{
                        stmt =  conexao.prepareStatement(sql);
                        stmt.setString(1, fornecedor.getNomeFantasia());
                        stmt.setString(2, fornecedor.getRazaoSocial());
                        stmt.setInt(3, fornecedor.getCNPJ());
                        stmt.setString(4, fornecedor.getEndereco());
                        stmt.setString(5, fornecedor.getBairro());
                        stmt.setString(6, fornecedor.getCidade());
                        stmt.setInt(7, fornecedor.getCEP());
                        stmt.setString(8, fornecedor.getEmail());
                        stmt.setInt(9, fornecedor.getTelefone());
                       

                        stmt.execute();
                        stmt.close();
                    }catch (Exception e){
                        throw new RuntimeException("Erro ao inserir"+e);
                    }
         } 
         
         public void Alterar(Fornecedor fornecedor){
             String sql = "UPDATE cliente NomeFantasia = ?, RazaoSocial = ?, CNPJ = ?, Endereco = ?, Bairro = ?, Cidade = ?, CEP = ?, Email = ?, Telefone = ?) WHERE id = ? ";
                    try{
                        stmt =  conexao.prepareStatement(sql);
                        stmt.setString(1, fornecedor.getNomeFantasia());
                        stmt.setString(2, fornecedor.getRazaoSocial());
                        stmt.setInt(3, fornecedor.getCNPJ());
                        stmt.setString(4, fornecedor.getEndereco());
                        stmt.setString(5, fornecedor.getBairro());
                        stmt.setString(6, fornecedor.getCidade());
                        stmt.setInt(7, fornecedor.getCEP());
                        stmt.setString(8, fornecedor.getEmail());
                        stmt.setInt(9, fornecedor.getTelefone());
                        stmt.execute();
                        stmt.close();
                      }catch (Exception e){
                        throw new RuntimeException("Erro ao alterar"+e);
                    }
         } 
         
         
         public void Excluir(int valor){
             String sql = "DELETE FROM cliente WHERE id = "+valor;
                    try{
                        st = conexao.createStatement();
                        st.execute(sql);
                        st.close();
                       
                        
                    }catch (Exception e){
                        throw new RuntimeException("Erro ao excluir"+e);
                    }
         } 

    public ArrayList<Fornecedor> ListarTodos() {
        throw new UnsupportedOperationException(); //To change body of generated methods, choose Tools | Templates.
    }

   

   

   

    
}
