/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;     
import view.TelaCadastroFuncionario;
import java.sql.Statement;
import java.sql.ResultSet;
import Model.Funcionario;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import Table.FuncionarioTableModel;

import java.sql.Connection;
import java.sql.PreparedStatement;     
import view.TelaCadastroCliente;
import java.sql.Statement;
import view.TelaFuncionario;
import java.sql.ResultSet;
import Model.Funcionario;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;


/**
 *
 * @author leticia_2
 */
public class FuncionarioDao {
  
    private Connection conexao;
    private PreparedStatement stmt;
    private Statement st;
    private ResultSet rs;
    
     public FuncionarioDao(){
           conexao = new ConnectionFactory().getConexao();
    }
             public boolean cadastrar(Funcionario funcionario){
                 Boolean res = false;
             String sql = "INSERT INTO funcionario(nome, cpf, rg, dataNascimento, email, telefone, endereco, cep, bairro, usuario, senha, funcao) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
                    try{
                        stmt =  conexao.prepareStatement(sql);
                        stmt.setString(1, funcionario.getNome());
                        stmt.setString(2, funcionario.getCpf());
                        stmt.setString(3,funcionario.getRg());
                        stmt.setDate(4, funcionario.getDataNascimento());
                        stmt.setString(5, funcionario.getEmail());
                        stmt.setString(6, funcionario.getTelefone());
                        stmt.setString(7, funcionario.getEndereco());
                        stmt.setString(8, funcionario.getCep());
                        stmt.setString(9, funcionario.getBairro());
                        stmt.setString(10, funcionario.getUsuario());
                        stmt.setString(11, funcionario.getSenha());
                         stmt.setString(12, funcionario.getFuncao());
                        
          

                        stmt.execute();
                        stmt.close();
                    res = true;
        }catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("Erro: " + ex.getMessage());
        }
                    return res;
         } 
         
         public boolean alterar(Funcionario funcionario){
             Boolean res = false;
             System.out.println("entrei");
             
             String sql = "UPDATE Funcionario nome = ?, cpf = ?, rg = ?, dataNascimento = ?, email = ?, telefone = ?, endereco = ?, bairro= ?,cep= ?,usuario=?,senha= ?, funcao=?) WHERE id = ? ";
                    try{
                         stmt =  conexao.prepareStatement(sql);
                         
                        stmt.setString(1, funcionario.getNome());
                        stmt.setString(2, funcionario.getCpf());
                        stmt.setString(3,funcionario.getRg());
                        stmt.setDate(4, funcionario.getDataNascimento());
                        stmt.setString(5, funcionario.getEmail());
                        stmt.setString(6, funcionario.getTelefone());
                        stmt.setString(7, funcionario.getEndereco());
                        stmt.setString(8, funcionario.getBairro());
                        stmt.setString(9, funcionario.getCep());
                        stmt.setString(10, funcionario.getUsuario());
                        stmt.setString(11, funcionario.getSenha());
                         stmt.setString(12, funcionario.getFuncao());
                        stmt.execute();
                        stmt.close();
                     res = true;
        }catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("Erro: " + ex.getMessage());
        }
        
        return res;
         
         } 
         
         
         public boolean Excluir(Integer funcionarioID){
             Boolean res = false;
        
        String sql = "DELETE FROM funcionario WHERE FuncionarioID = ?;";
        
        try{
            stmt =  conexao.prepareStatement(sql);
            
            stmt.setInt(1, funcionarioID);
            
            stmt.execute();
            
            stmt.close();
            
            res = true;
        } catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("Erro: " + ex.getMessage());
        }
        
        return res;
}
         public ArrayList<Funcionario> listarTodos() {
        String sql = "select * from funcionario;";
        
        ArrayList<Funcionario> funcionarios = new ArrayList<>();
        
        try {
            stmt = conexao.prepareStatement(sql);
            
            rs = stmt.executeQuery();
                                    
        
          while(rs.next()) {
                
                  /* funcionarios.add(new Funcionario ( rs.getInt("funcionarioId")),rs.getString("nome"), rs.getString("cpf"), rs.getString("rg"), rs.getDate("dataNascimento"), 
                    rs.getString("email"), rs.getString("telefone"), rs.getString("endereco"), rs.getString("bairro"),  
                    rs.getString("cep"), rs.getString("usuario"),rs.getString("senha"),rs.getString("funcao"),rs.getString("sexo"));*/
                 funcionarios.add(new Funcionario(rs.getInt("funcionarioId"), rs.getString("nome"), rs.getString("cpf"), rs.getString("rg"), rs.getDate("dataNascimento"),
                    rs.getString("email"), rs.getString("telefone"), rs.getString("endereco"), rs.getString("bairro"),
                    rs.getString("cep"), rs.getString("usuario"), rs.getString("senha"), rs.getString("funcao"), rs.getString("sexo")));
            }            
            
            rs.close();
            stmt.close();
        } catch(SQLException ex) {
            ex.printStackTrace();
            
            System.out.println("Erro: " + ex.getMessage());
        }
        
        return funcionarios;
    }

    
}