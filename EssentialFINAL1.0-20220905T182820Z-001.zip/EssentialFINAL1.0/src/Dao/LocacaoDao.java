/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Frota;
import Model.Locacao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import java.sql.Connection;
import java.sql.PreparedStatement;     
import view.TelaCadastroCliente;
import java.sql.Statement;
import view.TelaCadastroFuncionario;
import java.sql.ResultSet;
import Model.Cliente;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *  
 * @author leticia_2
 */
public class LocacaoDao {
    
    private Connection conexao;
    private PreparedStatement stmt;
    private Statement st;
    private ResultSet rs;
    
         public LocacaoDao(){
           conexao = new ConnectionFactory().getConexao();
    }
    
    
    public Boolean cadastrar(Locacao locacao){
        Boolean res = false;
        
        String sql = "INSERT INTO locacao (nomeCliente, dataLocacao, dataEntrega, servicos, marca, dataDevolucao, placa) " + 
            "VALUES (?, ?, ?, ?, ?, ?, ?);";
        
        try{
            stmt =  conexao.prepareStatement(sql);

            stmt.setString(1, locacao.getNomeCliente());  
            stmt.setDate(2, locacao.getDataLocacao());
            stmt.setDate(3, locacao.getDataEntrega());
            stmt.setString(4, locacao.getServicos());
            stmt.setString(5, locacao.getMarca());
            stmt.setDate(6, locacao.getDataDevolucao());
            stmt.setString(7, locacao.getPlaca());
           
            stmt.execute();

            stmt.close();
            
            res = true;
        }catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("Erro: " + ex.getMessage());
        }
        
        return res;
     } 

    public Boolean alterar(Locacao locacao){
        Boolean res = false;
        
        System.out.println("entrei");
        
        String sql = "UPDATE locacao SET nomeCliente = ?,  dataLocacao = ?, dataEntrega = ?, servicos = ?, marca = ? , dataDevolucao = ?, placa = ? WHERE clienteId = ?;";
        
        try{
            stmt =  conexao.prepareStatement(sql);
            
            stmt.setString(1, locacao.getNomeCliente());
           
            stmt.setDate(2, locacao.getDataLocacao());
            stmt.setDate(3, locacao.getDataEntrega());
            stmt.setString(4, locacao.getServicos());
            stmt.setString(5, locacao.getMarca());
            stmt.setDate(6, locacao.getDataDevolucao());
            stmt.setInt(7, locacao.getIdLocacao());
            stmt.setString(8, locacao.getPlaca());
            stmt.execute();
            stmt.close();
            
            res = true;
        }catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("Erro: " + ex.getMessage());
        }
        
        return res;
            
    }
    
    public Boolean excluir(Integer idLocacao){
        Boolean res = false;
        
        String sql = "DELETE FROM locacao WHERE idLocacao = ?;";
        
        try{
            stmt =  conexao.prepareStatement(sql);
            
            stmt.setInt(1, idLocacao);
            
            stmt.execute();
            
            stmt.close();
            
            res = true;
        } catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("Erro: " + ex.getMessage());
        }
        
        return res;
    } 
    
    public ArrayList<Locacao> listarTodos() {
        String sql = "select * from locacao;";
        
        ArrayList<Locacao> loci = new ArrayList<>();
        
        try {
            stmt = conexao.prepareStatement(sql);
            
            rs = stmt.executeQuery();
                                    
            while(rs.next()) {
                loci.add(new Locacao(rs.getInt("idLocacao"), rs.getString("nomeCliente"),rs.getDate("dataLocacao"), rs.getDate("dataEntrega"), rs.getDate("dataDevolucao"),
                    rs.getString("servicos"), rs.getString("Placa")));
            }            
            
            rs.close();
            stmt.close();
        } catch(SQLException ex) {
            ex.printStackTrace();
            
            System.out.println("Erro: " + ex.getMessage());
        }
        
        return loci;
    }
}
