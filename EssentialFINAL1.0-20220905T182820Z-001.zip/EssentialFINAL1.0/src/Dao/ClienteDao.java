/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

/**
 *
 * @author leticia_2
 */

import java.sql.Connection;
import java.sql.PreparedStatement;     
import view.TelaCadastroCliente;
import java.sql.Statement;
import view.TelaCadastroFuncionario;
import java.sql.ResultSet;
import Model.Cliente;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
               
public class ClienteDao {    
    private Connection conexao;
    private PreparedStatement stmt;  
    private ResultSet rs;
    
    public ClienteDao(){
        conexao = new ConnectionFactory().getConexao();
    }
    
    public Boolean cadastrar(Cliente cliente){
        Boolean res = false;
        
        String sql = "INSERT INTO cliente(nome, cpf , rg, dataNascimento, sexo, email, telefone, endereco, cidade, bairro, cep, cnh) " + 
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        
        try{
            stmt =  conexao.prepareStatement(sql);

            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getCpf());
            stmt.setString(3, cliente.getRg());
            stmt.setDate(4, cliente.getDataNascimento());
            stmt.setString(5, cliente.getSexo());
            stmt.setString(6, cliente.getEmail());
            stmt.setString(7, cliente.getTelefone());
            stmt.setString(8, cliente.getEndereco());
            stmt.setString(9, cliente.getBairro());
            stmt.setString(10, cliente.getCidade());
            stmt.setString(11, cliente.getCep());
            stmt.setString(12, cliente.getCnh());

            stmt.execute();

            stmt.close();
            
            res = true;
        }catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("Erro: " + ex.getMessage());
        }
        
        return res;
     } 

    public Boolean alterar(Cliente cliente){
        Boolean res = false;
        
        System.out.println("entrei");
        
        String sql = "UPDATE cliente SET nome = ?, cpf = ?, rg = ?, dataNascimento = ?, sexo = ?, email = ? , telefone = ?, " + 
            "endereco = ?, bairro = ?, cidade = ?, cep = ?, cnh = ? WHERE clienteId = ?;";
        
        try{
            stmt =  conexao.prepareStatement(sql);
            
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getCpf());
            stmt.setString(3, cliente.getRg());
            stmt.setDate(4, cliente.getDataNascimento());
            stmt.setString(5, cliente.getSexo());
            stmt.setString(6, cliente.getEmail());
            stmt.setString(7, cliente.getTelefone());
            stmt.setString(8, cliente.getEndereco());
            stmt.setString(9, cliente.getBairro());
            stmt.setString(10, cliente.getCidade());
            stmt.setString(11, cliente.getCep());
            stmt.setString(12, cliente.getCnh());
            stmt.setInt(13, cliente.getClienteId());
            
            stmt.execute();
            stmt.close();
            
            res = true;
        }catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("Erro: " + ex.getMessage());
        }
        
        return res;
    }

    public Boolean excluir(Integer clienteId){
        Boolean res = false;
        
        String sql = "DELETE FROM cliente WHERE clienteId = ?;";
        
        try{
            stmt =  conexao.prepareStatement(sql);
            
            stmt.setInt(1, clienteId);
            
            stmt.execute();
            
            stmt.close();
            
            res = true;
        } catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("Erro: " + ex.getMessage());
        }
        
        return res;
    } 
    
    public ArrayList<Cliente> listarTodos() {
        String sql = "select * from cliente;";
        
        ArrayList<Cliente> clientes = new ArrayList<>();
        
        try {
            stmt = conexao.prepareStatement(sql);
            
            rs = stmt.executeQuery();
                                    
            while(rs.next()) {
                clientes.add(new Cliente(rs.getInt("clienteId"), rs.getString("nome"), rs.getString("cpf"), rs.getString("rg"), rs.getDate("dataNascimento"), 
                    rs.getString("sexo"), rs.getString("email"), rs.getString("telefone"), rs.getString("endereco"), rs.getString("bairro"), rs.getString("cidade"), 
                    rs.getString("cep"), rs.getString("cnh")));
            }            
            
            rs.close();
            stmt.close();
        } catch(SQLException ex) {
            ex.printStackTrace();
            
            System.out.println("Erro: " + ex.getMessage());
        }
        
        return clientes;
    }
}

         

