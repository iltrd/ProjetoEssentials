/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Frota;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import view.Cliente;
import view.TelaCadastroCliente;

/**
 *
 * @author leticia_2
 */
public class FrotaDao {
    private Connection conexao;
    private PreparedStatement stmt;
    private Statement st;
    
         public FrotaDao(){
           conexao = new ConnectionFactory().getConexao();
    }
    
         public void Cadastrar(Frota frota){
             String sql = "INSERT INTO cliente(Placa, Modelo, ano, Cor, Categoria, Motor, FornecedorID) VALUES (?,?,?,?,?,?,?)";
                    try{
                        stmt =  conexao.prepareStatement(sql);
                        stmt.setString(1, frota.getPlaca());
                        stmt.setString(2, frota.getModelo());
                        stmt.setInt(3, frota.getAno());
                        stmt.setString(4, frota.getCor());
                        stmt.setString(5, frota.getCategoria());
                        stmt.setString(1, frota.getMotor());
                        stmt.setInt(1, frota.getFornecedorID());
                       
                        stmt.execute();
                        stmt.close();
                    }catch (Exception e){
                        throw new RuntimeException("Erro ao inserir"+e);
                    }
         } 
         
         public void Alterar(Frota frota){
             String sql = "UPDATE cliente Placa = ?, Modelo = ?, Ano = ?, Cor = ?, Categoria = ?, Motor = ? , FornecedorID = ?) WHERE id = ? ";
                    try{
                        stmt =  conexao.prepareStatement(sql);
                        stmt.setString(1, frota.getPlaca());
                        stmt.setString(2, frota.getModelo());
                        stmt.setInt(3, frota.getAno());
                        stmt.setString(4, frota.getCor());
                        stmt.setString(5, frota.getCategoria());
                        stmt.setString(1, frota.getMotor());
                        stmt.setInt(1, frota.getFornecedorID());;
                        stmt.execute();
                        stmt.close();
                      }catch (Exception e){
                        throw new RuntimeException("Erro ao alterar"+e);
                    }
         } 
         
         
         public void Excluir(int valor){
             String sql = "DELETE FROM cliente WHERE id = "+valor;
                    try{
                        st = conexao.createStatement();
                        st.execute(sql);
                        st.close();
                       
                        
                    }catch (Exception e){
                        throw new RuntimeException("Erro ao excluir"+e);
                    }
         } 
         
}
