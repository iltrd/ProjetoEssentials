/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Table;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import Model.Funcionario;
/**
 *
 * @author leticia_2
 */
public class FuncionarioTableModel extends AbstractTableModel{
 public static final int Nome= 0;
    public static final int CPF = 1;
    public static final int RG =2;
    public static final int DataNascimento = 3;
    public static final int Email = 4;
    public static final int Telefone = 5;
    public static final int Endereco = 6;
    public static final int CEP = 7;
    public static final int Login = 8;
    public static final int Senha = 9;
    public static final int Funcao = 10;
    public ArrayList<Funcionario> lista;
    
    public FuncionarioTableModel(ArrayList<Funcionario>l){
        lista = new ArrayList<Funcionario>(l);
    }
    
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 11;
    }

    @Override
    public Object getValueAt(int linhas, int colunas) {
      Funcionario funcionario = lista.get(linhas);
      
        if(colunas == Nome) return funcionario.getNome();
        if(colunas == CPF) return funcionario.getCpf();
        if(colunas == RG) return funcionario.getRg();     
        if(colunas == DataNascimento) return funcionario.getDataNascimento();      
        if(colunas == Email) return funcionario.getEmail();
        if(colunas == Telefone) return funcionario.getTelefone();
        if(colunas == Endereco) return funcionario.getEndereco();
        if(colunas == CEP) return funcionario.getCep();
        if(colunas == Login) return funcionario.getUsuario();
        if(colunas == Senha) return funcionario.getSenha();
        if(colunas == Funcao) return funcionario.getFuncao();
        
        return "";
    }
    
    @Override
    public String getColumnName(int colunas ){
           Funcionario funcionario =lista.get(colunas);
        if(colunas == Nome) return "Nome";
        if(colunas == CPF) return "CPF";
        if(colunas == RG) return "RG";
        if(colunas == DataNascimento) return"DataNascimento";
        if(colunas == Email) return "Email";
        if(colunas == Telefone) return "Telefone";
        if(colunas == Endereco) return "Endereco";
        if(colunas == CEP) return "CEP";
        if(colunas == Login) return "Login";
        if(colunas == Senha) return "Senha";
        if(colunas == Funcao) return "Funcao";
        return "";
    }
}
