/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Table;
import Model.Frota;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author leticia_2
 */
public class FrotaTableModel extends AbstractTableModel{
 public static final int VeiculoID= 0;
    public static final int Placa = 1;
    public static final int Modelo = 2;
    public static final int Ano = 3;
    public static final int Cor = 4;
    public static final int Categoria = 5;
    public static final int Motor = 6;
    public static final int FornecedorID = 7; 
    public ArrayList<Frota> lista;
    
    public FrotaTableModel (ArrayList<Frota>l){
        lista = new ArrayList<Frota>(l);
    }
    @Override
    public int getRowCount() {
        return lista.size();
        
    }

    @Override
    public int getColumnCount() {
        return 8 ;
    }

    @Override
    public Object getValueAt(int linhas, int colunas) {
         Frota frota =lista.get(linhas);
        if(colunas == VeiculoID ) return frota.getVeiculoID();
        if(colunas == Placa) return frota.getPlaca();
        if(colunas == Modelo) return frota.getModelo();
        if(colunas == Ano) return frota.getAno();
        if(colunas == Cor) return frota.getCor();
        if(colunas == Categoria) return frota.getCategoria();
        if(colunas == Motor) return frota.getMotor();
        if(colunas == FornecedorID) return frota.getFornecedorID();
        
        return "";
    }
    
   @Override 
   
     public String getColumnName ( int colunas){
      Frota frota =lista.get(colunas);
        if(colunas == VeiculoID) return "VeiculoID";
        if(colunas == Placa) return "Paca";
        if(colunas == Modelo) return "Modelo";
        if(colunas == Ano) return "Ano";
        if(colunas == Cor) return"Cor";
        if(colunas == Categoria) return "Categoria";
        if(colunas == Motor) return "Motor";
        if(colunas == FornecedorID) return "FornecedorID";
        
        return "";
    
     }
}
