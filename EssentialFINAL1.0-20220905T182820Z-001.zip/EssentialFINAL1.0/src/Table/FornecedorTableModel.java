/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Table;

import Model.Fornecedor;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;


/**
 *
 * @author leticia_2
 */
public class FornecedorTableModel extends AbstractTableModel {
    
     public static final int FornecedorID = 0;
    public static final int NomeFantasia = 1;
    public static final int RazaoSocial = 2;
    public static final int CNPJ = 3;
    public static final int Endereco = 4;
    public static final int Bairro = 5;
    public static final int Cidade = 6;
    public static final int CEP = 7;
    public static final int Email = 8;
    public static final int Telefone = 9;
    public ArrayList<Fornecedor> lista;
    
    public FornecedorTableModel(ArrayList<Fornecedor>l){
        lista = new ArrayList<Fornecedor>(l);
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 10;
    }

    @Override
    public Object getValueAt(int linhas, int colunas) {
        Fornecedor fornecedor =lista.get(linhas);
        if(colunas == FornecedorID) return fornecedor.getFornecedorID();
        if(colunas == NomeFantasia) return fornecedor.getNomeFantasia();
        if(colunas == RazaoSocial) return fornecedor.getRazaoSocial();
        if(colunas == CNPJ) return fornecedor.getCNPJ();
        if(colunas == Endereco) return fornecedor.getEndereco();
        if(colunas == Bairro) return fornecedor.getBairro();
        if(colunas == Cidade) return fornecedor.getCidade();
        if(colunas == CEP) return fornecedor.getCEP();
        if(colunas == Email) return fornecedor.getEmail();
        if(colunas == Telefone) return fornecedor.getTelefone();
        return "";
        
        
    }
    
    @Override
    public String getColumnName(int colunas){
        
        if(colunas == FornecedorID) return "FornecedorID";
        if(colunas == NomeFantasia) return "NomeFantasia";
        if(colunas == RazaoSocial) return "RazaoSocial";
        if(colunas == CNPJ) return "CNPJ";
        if(colunas == Endereco) return"Endereco";
        if(colunas == Bairro) return "Bairro";
        if(colunas == Cidade) return "Cidade";
        if(colunas == CEP) return "CEP";
        if(colunas == Email) return "Email";
        if(colunas == Telefone) return "Telefone";
        return "";
    }
}
