/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Table;
import Model.Locacao;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author leticia_2
 */
public class LocacaoTableModel extends AbstractTableModel {
    public static final int LocacaoID = 0;
    public static final int ClienteID = 1;
    public static final int Data_Locacao = 2;
    public static final int Data_Entrega= 3;
    public static final int Servico= 4;
    public static final int FuncionarioID = 5;
    public static final int VeiculoID = 6;
     public static final int Devolucao = 7;
         public ArrayList<Locacao> lista;
         
         public LocacaoTableModel (ArrayList<Locacao>l){
             lista = new ArrayList<Locacao>(l);
         
         }
    
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 8;
    }

    @Override
    public Object getValueAt(int linhas, int colunas) {
        Locacao locacao =lista.get(linhas);
        if(colunas == LocacaoID) return locacao.getLocacaoID();
        if(colunas == ClienteID) return locacao.getClienteID();
        if(colunas == Data_Locacao) return locacao.getData_Locacao();
        if(colunas == Data_Entrega) return locacao.getData_Entrega();
        if(colunas == Servico) return locacao.getServico();
        if(colunas == FuncionarioID) return locacao.getFuncionarioID();
        if(colunas == VeiculoID) return locacao.getVeiculoID();
        if(colunas == Devolucao) return locacao.getDevolucao();
        
        return "";
    }
    
    @Override 
    public String getColumnName( int colunas){
        Locacao locacao  =lista.get(colunas);
        if(colunas == LocacaoID) return "LocacaoID";
        if(colunas == ClienteID) return "ClienteID";
        if(colunas == Data_Locacao) return "Data_Locacao";
        if(colunas == Data_Entrega) return "Data_Entrega";
        if(colunas == Servico) return"Servicos";
        if(colunas == FuncionarioID) return "FuncionarioID";
        if(colunas == VeiculoID) return "VeiculoID";
        if(colunas == Devolucao) return "Devolucao";
       
        return "";
    }
    
}
