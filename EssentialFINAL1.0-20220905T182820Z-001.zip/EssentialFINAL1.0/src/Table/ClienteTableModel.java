/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Table;
import Model.Cliente;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *stmt =  
 * @author leticia_2
 */
public class ClienteTableModel  extends AbstractTableModel{
    
     public static final int Nome= 0;
    public static final int CPF = 1;
    public static final int RG = 2;
    public static final int CNH = 3;
    public static final int DataNascimento = 4;
    public static final int Sexo = 5;
    public static final int Email = 6;
    public static final int Telefone = 7;
    public static final int Endereco = 8;
    public static final int Bairro = 9;
     public static final int Cidade = 10;
    public static final int CEP = 11;
    public ArrayList<Cliente> lista;
    
    
     public ClienteTableModel(ArrayList<Cliente>l){
        lista = new ArrayList<Cliente>(l);
    }

    @Override
    public int getRowCount() {
         return lista.size();

    }

    @Override
    public int getColumnCount() {
       return 12;
    }

    @Override
    public Object getValueAt(int linhas, int colunas) {
        Cliente cliente =lista.get(linhas);
        if(colunas == Nome) return cliente.getNome();
        if(colunas == CPF) return cliente.getCpf();
        if(colunas == RG) return cliente.getRg();
        if(colunas == CNH) return cliente.getCnh();
        if(colunas == DataNascimento) return cliente.getDataNascimento();
        if(colunas == Sexo) return cliente.getSexo();
        if(colunas == Email) return cliente.getEmail();
        if(colunas == Telefone) return cliente.getTelefone();
        if(colunas == Endereco) return cliente.getEndereco();
        if(colunas == Bairro) return cliente.getBairro();
         if(colunas == Cidade) return cliente.getCidade();
        if(colunas == CEP) return cliente.getCep();
        return "";
    }
    
    @Override
    public String getColumnName (int colunas){
         Cliente cliente =lista.get(colunas);
        if(colunas == Nome) return "Nome";
        if(colunas == CPF) return "CPF";
        if(colunas == RG) return "RG";
        if(colunas == CNH) return "CNH";
        if(colunas == DataNascimento) return"DataNascimento";
        if(colunas == Sexo) return "Sexo";
        if(colunas == Email) return "Email";
        if(colunas == Telefone) return "Telefone";
        if(colunas == Endereco) return "Endereco";
        if(colunas == Bairro) return "Bairro";
        if(colunas == Cidade) return "Cidade";
        if(colunas == CEP) return "CEP";
        return "";
    }

    
}
